Reionization models
==================================

.. autoclass:: camb.reionization.ReionizationModel
   :members:

.. autoclass:: camb.reionization.TanhReionization
   :show-inheritance:
   :members:




