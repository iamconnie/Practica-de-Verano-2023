Recombination models
==================================


.. autoclass:: camb.recombination.RecombinationModel
   :members:

.. autoclass:: camb.recombination.Recfast
   :show-inheritance:
   :members:

.. autoclass:: camb.recombination.CosmoRec
   :show-inheritance:
   :members:

.. autoclass:: camb.recombination.HyRec
   :show-inheritance:
   :members:



