Basic functions
==================================


.. automodule:: camb
   :members: get_results, get_background, get_transfer_functions, set_params, set_params_cosmomc, read_ini, get_matter_power_interpolator, get_age, get_zre_from_tau, set_feedback_level, run_ini, get_valid_numerical_params
